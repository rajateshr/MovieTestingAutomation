package PageObjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import TestCases.BaseClass;

public class MoviePageObjects extends BaseClass {
	
	public String ReleaseDateIMDB;
	public String CountryOfOriginIMDB;
	public String ReleaseDateWiki;
	public String CountryOfOriginWiki;
	
	public String MovieNameIMDB = excel.getStringData("Movie", 1, 3);
	public String MovieNameWiki = excel.getStringData("Movie", 1, 4);
	
	/*XPATHS in IMDB Page*/
	By suggestsearch = By.xpath("//*[@id='suggestion-search']"); /*XPath for the Search Textbox in IMDB page*/
	By searchsuggestionIMDB = By.xpath("//div[text()='"+MovieNameIMDB+"']"); /*XPath for Movie in search Suggestion dropdown in IMDB page*/
	By countryoforiginIMDB = By.xpath("//span[text()='Country of origin']//following-sibling::div/ul[@role='presentation']/li/a"); /*XPath for Country of Origin of searched movie in IMDB*/
	By countrywisearrow = By.xpath("//a[contains(@href,'/releaseinfo?ref_=tt_dt_rdat')]"); /*XPath for arrow dropdown near to Release date*/
	
	/*XPATHS in Wiki Page*/
	By searchwikipidea = By.xpath("//*[@id='searchInput']"); /*XPath for Search Textbox in wikipedia*/
	By searchsuggestionWiki = By.xpath("//div[@class='suggestions-results']/a[@title='"+MovieNameWiki+"']"); /*XPath for Movie in search Suggestion dropdown*/
	By country = By.xpath("//th[text()='Country']/following-sibling::td"); /*XPath for Country of Origin of searched movie in wiki page*/
	By releasedatewiki = By.xpath("//div[text()='Release date']/parent::th/following-sibling::td/div/ul/li"); /*XPath for Release date of searched movie in wiki page*/
	
	//This is function to validate whether Country Origin and Release date in IMBD is same as in Wiki
	public void validationofReleaseDateCountry() throws Throwable
	{
		
		String imdburl=excel.getStringData("Movie", 1, 0);
		String wikiurl=excel.getStringData("Movie", 1, 1);
		String searchvalue=excel.getStringData("Movie", 1, 2);
		
		//This is the function to enter the IMDB url
		driver.get(imdburl);
		Thread.sleep(3000);
		
		logger.info("Entering the Keyword " +searchvalue);
		driver.findElement(suggestsearch).sendKeys(searchvalue);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		logger.info("Clicking or selecting search suggestion dropdown");
		driver.findElement(searchsuggestionIMDB).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//Capturing the text of Country of Origin for the movie
	    CountryOfOriginIMDB=driver.findElement(countryoforiginIMDB).getText();
	    logger.info("The country of origin for the movie " +searchvalue+ " in IMDB page ---> " +CountryOfOriginIMDB );
	   
		logger.info("Clicking the arrow button near Release Date for the movie in IMDB page");
		driver.findElement(countrywisearrow).click();	
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//Capturing the text of Release date for the movie
		String CountryOfReleaseImdb=CountryOfOriginIMDB;
		if(CountryOfOriginIMDB.equalsIgnoreCase("United States"))
		{
			CountryOfReleaseImdb="USA";	
		}
		if(CountryOfOriginIMDB.equalsIgnoreCase("United Kingdom"))
		{
			CountryOfReleaseImdb="UK";	
		}
		WebElement releasedateIMDB=driver.findElement(By.xpath("//td[@class='release-date-item__country-name']/a[normalize-space(text())='"+CountryOfReleaseImdb+"']/parent::td/following-sibling::td"));
		ReleaseDateIMDB=releasedateIMDB.getText();
		logger.info("The Release date of movie " +searchvalue+ " in IMDB page ---> " +ReleaseDateIMDB);
		//This is the function to enter the Wiki url
		driver.get(wikiurl);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		logger.info("Entering the Keyword " +searchvalue);
		driver.findElement(searchwikipidea).sendKeys(searchvalue);
		Thread.sleep(3000);
		logger.info("Selecting/Clicking the Search suggestion for " +searchvalue);
		driver.findElement(searchsuggestionWiki).click();
		Thread.sleep(3000);
		ReleaseDateWiki=driver.findElement(releasedatewiki).getText();
		logger.info("The Release date of movie " +searchvalue+ " in wiki page ---> " +ReleaseDateWiki);
	
		//Capturing the text of Country of Origin for the movie in wike page
		CountryOfOriginWiki=driver.findElement(country).getText();
		logger.info("The country of origin for the movie " +searchvalue+ " in wiki page ---> " +CountryOfOriginWiki);
		Thread.sleep(3000);
		//Validating whether Release date of movie in IMDB page is same as in Wiki page
		Assert.assertEquals(ReleaseDateIMDB,ReleaseDateWiki);
	     logger.pass("The Release date of the film in IMDB is same as in wiki =PASS ");
	   //Validating whether Country of origin for the movie in IMDB page is same as in Wiki page
	     Assert.assertEquals(CountryOfOriginIMDB,CountryOfOriginWiki);
	     logger.pass("The Country of origin of the Film in IMDB is same as in wiki =PASS ");
	}
}