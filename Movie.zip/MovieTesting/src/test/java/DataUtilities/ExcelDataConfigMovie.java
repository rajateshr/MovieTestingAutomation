package DataUtilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

public class ExcelDataConfigMovie {
	static Properties pro;

	public  ExcelDataConfigMovie() {
		File src=new File("C:\\workspace\\QaAutomation\\Flipkart\\Configeration\\Config.properties");
		
		try {
			FileInputStream fis = new FileInputStream(src);
			pro=new Properties();
			pro.load(fis);
		} catch (Exception e) {
			System.out.println("Unable to load the file " +e.getMessage());
		}
		}
		
		
		public String getBrowser()
		{
			return pro.getProperty("Browser");
		}
		public String getStagingUrl()
		{
			return pro.getProperty("URL");

		}
	
}
