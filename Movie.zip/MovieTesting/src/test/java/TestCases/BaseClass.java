package TestCases;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import DataUtilities.BrowserFactoryMovie;
import DataUtilities.ExcelDataConfigMovie;
import DataUtilities.ExcelLib;


public class BaseClass extends BrowserFactoryMovie {
	public static WebDriver driver;
	public static ExcelLib excel;
	public ExcelDataConfigMovie config;
	public static ExtentTest logger;
	public static ExtentReports extent;


    @Parameters({"browser"}) 
	@BeforeSuite
	  public void launchBrowser(String browser)throws IOException
	  {
    	ExtentHtmlReporter reporter=new ExtentHtmlReporter(new File(System.getProperty("user.dir")+"/Reports/ExtentReportResults.html"));
		  excel=new ExcelLib();
		  config=new ExcelDataConfigMovie();
		  extent = new ExtentReports();
		  extent.attachReporter(reporter);
		  //driver=BrowserFactoryFK.startApplication(driver,config.getBrowser(),config.getStagingUrl());
		  driver=BrowserFactoryMovie.startApplication(driver,browser); 
	  }
	  @AfterSuite
	  public void tearDown()  throws IOException
	  {
		  BrowserFactoryMovie.quitBrowser(driver);		   
     }
	  
	  @AfterMethod
	  public void tearDownMethod(ITestResult result) throws IOException 
	  {
		  if(result.getStatus()==ITestResult.FAILURE)
		  {
			  logger.fail("Test Failed",MediaEntityBuilder.createScreenCaptureFromPath(BrowserFactoryMovie.captureScreenshot(driver)).build());
		  }
		  if(result.getStatus()==ITestResult.SUCCESS)
		  {
			  logger.pass("Test Passed", MediaEntityBuilder.createScreenCaptureFromPath(BrowserFactoryMovie.captureScreenshot(driver)).build());

		  }
		  extent.flush();
	  }
}
