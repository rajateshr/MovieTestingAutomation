package TestCases;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;


import PageObjects.MoviePageObjects;


public class MovieTest extends BaseClass 
{
	MoviePageObjects mp;
	  @Test(priority=1)
	  public void validatingDateandCountryOfOrigin() throws Throwable 
	  {
		    		  
		    logger = extent.createTest("Validate whether the Release date and Country of origin of the film in IMDB is same as in wiki");
		    mp=new MoviePageObjects();
		    mp.validationofReleaseDateCountry();
		    		     
	  }
	  
}
